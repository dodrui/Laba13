using Laba13;
using Laba10;
using System.Reflection;
namespace TestProject2

{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestAddElement()
        {
            MyObservableCollection<Aircraft> collection = new MyObservableCollection<Aircraft>();
            Aircraft elementToAdd = new Aircraft();

            collection.Add(elementToAdd);
            Assert.IsTrue(collection.Contains(elementToAdd));
        }

        [TestMethod]
        public void TestRemoveElement()
        {
            MyObservableCollection<Aircraft> collection = new MyObservableCollection<Aircraft>();
            Aircraft elementToRemove = new Aircraft();
            collection.Add(elementToRemove);

            collection.Remove(elementToRemove);

            Assert.AreEqual(0, collection.Count);
            Assert.IsFalse(collection.Contains(elementToRemove));
        }

        [TestMethod]
        public void TestIndexer()
        {
            MyObservableCollection<Aircraft> collection = new MyObservableCollection<Aircraft>(1);
            Aircraft elementToAdd = new Aircraft();
            collection.Add(elementToAdd);

            // Проверка чтения элемента по индексу
            Assert.AreEqual(elementToAdd, collection[0]);

            Aircraft newElement = new Aircraft
            {
                Model = "Истребитель",
                ProductionYear = 1950,
                EngineType = "ДВС",
                CrewNumber = 5
            };
            // Проверка записи элемента по индексу
            collection[0] = newElement;
            Assert.AreEqual(newElement, collection[0]);
        }

        [TestMethod]
        public void TestJournalEntryToString()
        {
            JournalEntry entry = new JournalEntry("Collection1", "Add", "Item: 1");
            string expected = entry.ToString();
            Assert.AreEqual(expected, entry.ToString());
        }

        [TestMethod]
        public void TestAddEntry()
        {
            Journal journal = new Journal();
            object source = new MyObservableCollection<Aircraft>();
            CollectionHandlerEventArgs args = new CollectionHandlerEventArgs("Added", new Aircraft());

            journal.AddEntry(source, args);

            Assert.AreEqual(1, journal.entries.Count);
        }

        [TestMethod]
        public void TestToString()
        {
            // Arrange
            Journal journal = new Journal();
            journal.AddEntry(new MyObservableCollection<Aircraft>(), new CollectionHandlerEventArgs("Added", new Aircraft()));
            journal.AddEntry(new MyObservableCollection<Aircraft>(), new CollectionHandlerEventArgs("Removed", new Aircraft()));

            // Act
            string result = journal.ToString();
            Console.WriteLine(result);
            // Assert
            string expected = "Коллекция: MyObservableCollection`1, Тип изменения: Added, Информация об объекте: ID: 0, Модель: Истребитель, Год выпуска: 1950, Тип двигателя: ДВС, Число членов экипажа: 5\n" +
                              "Коллекция: MyObservableCollection`1, Тип изменения: Removed, Информация об объекте: ID: 0, Модель: Истребитель, Год выпуска: 1950, Тип двигателя: ДВС, Число членов экипажа: 5\n";
            Assert.AreEqual(expected, result);
        }
    }
}